# MJC1 虚拟手接口 v1.2 — camera-mjc1-v1

2026-10-18：从独立 MJC1 v1.1 增加只读 `PROFILE`，版本变为 1.2；相机集成 profile 地址移至 `0xA0100000`。
这是已写入集成源码的独立虚拟手接口，**集成 bit 尚未生成或上板验收**。
实体舵机的 [v0.2.2 接口](interface.md) 继续独立；两者偏移、CTRL 位、角度格式不同，不能混用后端。

## 总线与时钟

PS HPM0_FPD128 → camera AXI Interconnect M11 → MJC1 AXI4-Lite32，地址 12 位，range4 KiB。
MJC1 和 M11 使用 PL1/约100 MHz；相机原控制总线 PL0/约200 MHz 保留。
32 位对齐读写；写必须 WSTRB=0xF，否则 SLVERR。AW/W 可独立到达；响应期间保持状态直到 READY。
未映射访问、向只读区写、重复或偶数反馈提交均 SLVERR。PS 使用原生 volatile uint32 和 dmb/dsb。

| 偏移 | 名称 | 权限 | 字段 |
|---|---|---|---|
| 0x000 | ID | R | `0x31434A4D`，MJC1 |
| 0x004 | VERSION | R | `0x00010002`，v1.2 |
| 0x008 | CTRL | RW | bit0 enable，bit1 virtual estop |
| 0x00C | CMD | W | [7:0]命令、[15:8]参数；01抓取、02释放、03预张快照、04力矩事件/保护复位 |
| 0x010+i×4 | TARGET_i | W | [11:0]计划目标，i=0..7；其余位忽略 |
| 0x030 | TORQUE_LIM | W | 每路4位，虚拟 load 阈值=level×64 |
| 0x034 | SPEED | W | [7:0]速度事件值 |
| 0x040 | STATUS | R | [2:0]FSM；bit3 busy、4 grasped、5 timeout、6 fault |
| 0x044 | FB_ACK | R | 最近实际提交的奇数序号 |
| 0x048 | PROFILE | R | **新增** `0x434D4A31`，CMJ1，相机共存 profile |
| 0x050+i×4 | PL_TARGET_i | R | FPGA FSM 当前输出 [11:0]；PS 发给 MuJoCo 的唯一目标来源 |
| 0x080+i×4 | FB_STAGE_i | RW | [11:0]位置、[21:12]虚拟load，其余位保留 |
| 0x0A0 | FB_COMMIT | W | 新的奇数序号；同一 PL 时钟沿提交8路 stage 并更新 ACK |

每个目标/反馈数组为8路。FSM：0 IDLE、1 PREGRASP、2 CLOSING、3 HOLD、4 RELEASING、5 PROTECT。
复位后 disable，反馈 offline；在线后持续50,000,000个MJC1时钟无新commit则掉线，随后 FSM 保护。
新commit优先于同周期watchdog递增。时钟实测约100.352 MHz，超时约0.498秒。

## MuJoCo 报文

TCP newline JSON，每包不超过65536字节，目标50 Hz（Linux调度非硬实时）。
PS→PC：`{"seq":2,"state":2,"target_raw":[1450,1450,1450,1450,1450,1450,1450,1450]}`。
PC→PS：同一seq、8项 `position_raw`、8项 `load_raw`；其余诊断字段可附带。
raw900对应0°，每单位0.1°，软件限0..1800；通道顺序是finger1..4，每指motor1、motor2。
load为MuJoCo actuator_force绝对值×32并限制0..1023，**不是实体舵机力矩标定值**。
当前演示 HOLD 可以由闭合计时超时触发，不作为抓住实体或力控成功的证明。

## 生命周期

只用配套固件hash、原生访问程序和本次启动的load receipt。旧MJC1-only基地址属于相机Gamma2，不得探测。
加载器先拒绝活动driver/MMIO用户及错误PS时钟/接口，配置后核对ID/版本/PROFILE，再加载相机模块。
客户端持共享profile锁和排他控制锁；重复控制或同时reload拒绝。相机运行中reload也因module存在拒绝。
传输结束/异常时请求virtual estop；板卡/AXI本身挂死时软件不保证能送达，该故障需硬件恢复。
