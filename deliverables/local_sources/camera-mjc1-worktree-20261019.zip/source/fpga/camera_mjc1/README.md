# 相机 + MJC1 共存固件（开发中）

独立分支 `feature/camera-mjc1-integration-20261018`，基线 main `ee52f09`。
**目前完成源码及构建入口，MJC1 单元仿真通过；未生成或加载集成 bit，未通过并发上板验收。**
原供应方版本为 2020.2_AR75986；原归档入口仍只接受2020.2。
2026-10-18用户授权使用本机2020.1做源码适配，增加显式 `compat2020.1` 路线。
适配从归档BD的顶层配置重建32个模块，用本机IP重新生成内部结构，不修改归档BD/XCI的版本号、不自动upgrade/downgrade。缺失IP或不支持参数直接报错。

## 结构

- 复用 `../camera_hw/scripts/create_project.tcl`，复制归档输入至新输出目录。
- 相机原 BD、IP、PS 参数、五份 XDC 和全部外部端口保持原样；保留四路硬件，当前运行软件仍只验收相机 0。
- 原 `ps8_0_axi_periph` 从 11 个 master 增至 12，新增 M11 连接 MJC1 AXI4-Lite32。
- 相机控制总线为 PL0/约 200 MHz；原 `proc_sys_reset_100M` 的名字不代表实际频率。
- MJC1 使用已启用的 PL1/约 100 MHz，新增独立复位；M11 跨域由 AXI Interconnect 生成。
- `rst_mjc1` 的 external/aux reset 均为低有效；aux 必须接常量 **1**，debug reset 接 0，dcm_locked 接 1。
- 不增加实体舵机输出。相机的 L17 等引脚继续按原约束工作。

| 功能 | 地址 | 范围 |
|---|---|---|
| 相机 0 Gamma | `0xA0040000` | 64 KiB，原值 |
| 相机 0 VDMA | `0xA0060000` | 64 KiB，原值 |
| 相机 reset GPIO | `0xA0080000` | 64 KiB，原值 |
| 其余相机寄存器 | `0xA0000000`～`0xA00AFFFF` 各既有窗口 | 全部原值 |
| MJC1 | **`0xA0100000`** | **4 KiB** |

旧 MJC1-only 的 `0xA0000000` 在相机中是 Gamma2，**不能沿用旧地址或旧 board_loop**。
独立的虚拟手 ABI 见 [接口说明](../../docs/design/mjc1_interface.md)，不等同实体手 v0.2.2 ABI。

## 创建与构建

### Vivado 2020.1 适配

```powershell
vivado -mode batch -source fpga/camera_mjc1/build.tcl -tclargs D:/Vitis/project_1/camera-compat-NEW build compat2020.1
```

需要PC的Python3。适配器检查所有原模块VLNV/显式参数、信号连接、接口及地址。
允许的唯一已审查元数据差异为PS的派生protection inventory新增FPD_GPV/CCI_GPV；原条目及标志必须不变。
不部署适配XSA的PS初始化、FSBL或启动文件，只允许在匹配现有Linux/PS配置下单独加载PL。
`adaptation_audit.json`通过仅代表配置意图核对通过，不代表实现或上板通过。
打包对2020.1要求额外adaptation标识及核对报告；2020.2路径继续独立。

### Vivado 2020.2 原归档路线

目标输出目录必须不存在；所有生成文件放到仓库之外。匹配工具中执行：

```powershell
vivado -mode batch -source fpga/camera_mjc1/build.tcl -tclargs D:/Vitis/project_1/camera-mjc1-build-001 prepare
```

`prepare` 只创建/校验 BD，输出 IP 状态和可审查 BD Tcl。完整构建使用另一个新目录：

```powershell
vivado -mode batch -source fpga/camera_mjc1/build.tcl -tclargs D:/Vitis/project_1/camera-mjc1-build-002 build
```

脚本检查相机 PS 配置、地址无冲突且原地址不变、外部端口不变、MJC1 复位、IP lock、综合/实现状态、DRC error、setup/hold slack。
输出 `camera_mjc1.bit`、XSA、BD Tcl、IP/资源/DRC/时序报告和 `implementation_gate.json`。
必须人工阅读时序报告中的未约束路径及 critical warning；构建成功不是上板并发成功。
在构建输出目录转换 raw bin，然后打包：

```powershell
bootgen -image camera_mjc1.bif -arch zynqmp -process_bitstream bin
python <仓库路径>/fpga/camera_mjc1/package.py .
```

`deployment.json` 固定产物 hash，`board_validation` 保持 pending。不要用旧 camera-only 或 MJC1-only bit 替代。

## MJC1 仿真

现有测试覆盖 ID、版本、CMJ1 标记、32 位写、PL 输出读回、反馈 commit、看门狗刷新/超时、部分写及未映射读拒绝。
不依赖相机 IP，可以用本机 2020.1：

```powershell
vivado -mode batch -source fpga/camera_mjc1/sim/run.tcl -tclargs D:/Vitis/project_1/mjc1-regression-NEW
```

2026-10-18 已运行：`MJC1_REGRESSION_PASS`。证据在 `D:/Vitis/project_1/camera_mjc1_validation_20261018/`。
这不是相机 BD/跨时钟 AXI 或整机时序验证。

## 部署与并发验收（待完成）

板端配套见 [原生访问程序](../../host/mjc1_native/README.md)。先停止虚拟手控制进程和相机采集，再卸载相机模块；旧程序必须释放 MMIO。
加载 composite 一次后，相机启停仅操作采集程序，不再调用 camera-only loader，不重新配置 PL。
PC 继续使用现有 MuJoCo observer 的 loopback8765，SSH reverse tunnel18765及相机入口8766。

需依次验收：

1. 匹配工具 BD/IP、完整实现、资源/时序/DRC。
2. 板端原生 32 位读 CMJ1 标记，单独相机出真实 1080p 图像。
3. MJC1 单独完成开合及反馈 ack；失联进入 PROTECT。
4. 两者同时运行，核对实时帧、帧率、至少十轮 PL 状态/反馈 ack，以及 SSH 稳定性。
5. 停止/重启相机时，PL 控制连续；终止虚拟手连接时，相机继续；记录结果与限制。

本次适配尚未替换板卡上的MJC1-only R2。没有写 SD/Flash、改启动配置、提交或推送。

## MJC1 源码来源

来自本机独立实测工程 `D:/Vitis/project_1/mjc1_fpd_20261018` 的 reset-fixed R2。
原 `grasp_fsm.sv` SHA256 `8fd8dbd510633dfbcb71537ccbb8b53bb8383d3ba83beda3fc6dd0d4681338c7`，未改。
原 `mujoco_axi_core.sv` SHA256 `40c29e89a8548618ed05e53ef4d4cbe64ee7b25453b87b455fed69be99ca66a9`；集成增加只读 CMJ1 标记，保留反馈 commit 优先于 watchdog 的修正。
原纯 Verilog AXI wrapper SHA256 `0fbe614b9b1032c41d83dafcad5c1a23c99a7eddaef36b9b0325dd97b3d4b42f`，未改。
已有回归沿用并增加 CMJ1 标记检查。板端 native32 访问来自同一实测工程；不使用 Python struct.pack_into 读写 PL。
