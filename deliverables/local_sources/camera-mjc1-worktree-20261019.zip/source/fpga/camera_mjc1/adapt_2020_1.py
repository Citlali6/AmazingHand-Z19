"""Recreate camera BD intent with installed IP; never rewrite the archived BD/XCI.

Only the top-level IP intent is replayed. Vivado regenerates the internal AXI
hierarchies. Missing VLNVs or unsupported parameters fail instead of being dropped.
"""
import argparse
import hashlib
import json
from pathlib import Path


def require(value, message):
    if not value:
        raise RuntimeError(message)


def audit(bd, rebuilt, destination):
    original = json.loads(bd.read_text(encoding='utf-8'))['design']
    actual = json.loads(rebuilt.read_text(encoding='utf-8'))['design']
    require(set(original['components']) == set(actual['components']), 'Camera cell set changed')
    count = 0
    differences = []
    for name, cell in original['components'].items():
        other = actual['components'][name]
        require(cell['vlnv'] == other['vlnv'], 'VLNV changed: ' + name)
        for key, item in cell.get('parameters', {}).items():
            value = other.get('parameters', {}).get(key, {}).get('value')
            count += 1
            if item['value'] == value:
                continue
            # 2020.1 adds two entries to the PS derived protection inventory.
            # Existing access flags/addresses must remain identical. No PS init
            # or boot files from the adapted XSA are deployed by the PL loader.
            if key == 'PSU__PROTECTION__SLAVES' and value is not None:
                before, after = set(item['value'].split('|')), set(value.split('|'))
                require(not (before - after) and after - before == {
                    'FPD;FPD_GPV;FD700000;FD7FFFFF;1',
                    'FPD;CCI_GPV;FD6E0000;FD6EFFFF;1'}, 'Unexpected PS protection difference')
                differences.append(dict(cell=name, parameter=key, added=sorted(after-before)))
            else:
                raise RuntimeError('Camera parameter changed: %s/%s: %r -> %r' %
                                   (name, key, item['value'], value))
    for kind, member in [('nets', 'ports'), ('interface_nets', 'interface_ports')]:
        normalize = lambda d: {n: sorted(v[member]) for n, v in d[kind].items()}
        require(normalize(original) == normalize(actual), 'Camera connectivity changed: ' + kind)
    require(original['interface_ports'] == actual['interface_ports'], 'External ports changed')
    def addresses(d):
        return {(c, s, n): v for c, x in d['addressing'].items()
                for s, y in x['address_spaces'].items() for n, v in y['segments'].items()}
    require(addresses(original) == addresses(actual), 'Camera address segments changed')
    report = dict(profile='camera-intent-2020.1-v1', intent_audit='passed',
                  source_bd_sha256=hashlib.sha256(bd.read_bytes()).hexdigest(),
                  rebuilt_bd_sha256=hashlib.sha256(rebuilt.read_bytes()).hexdigest(),
                  cells=len(original['components']), parameters_checked=count,
                  nets_checked=len(original['nets']), interfaces_checked=len(original['interface_nets']),
                  address_segments_checked=len(addresses(original)),
                  reviewed_derived_metadata=differences,
                  implementation='not_checked', board_validation='pending')
    with destination.open('x', encoding='utf-8') as out:
        json.dump(report, out, indent=2)
        out.write('\n')
    print('CAMERA_2020_1_INTENT_AUDIT_PASS')


def q(value):
    value = str(value)
    for old, new in [('\\', '\\\\'), ('"', '\\"'), ('$', '\\$'),
                     ('[', '\\['), (']', '\\]'), ('\n', '\\n'), ('\r', '\\r')]:
        value = value.replace(old, new)
    return '"' + value + '"'


def emit(bd, destination):
    design = json.loads(bd.read_text(encoding='utf-8'))['design']
    assert design['design_info']['tool_version'] == '2020.2'
    assert design['design_info']['device'] == 'xczu19eg-ffvc1760-2-i'
    lines = ['# Generated from immutable 2020.2 BD intent; NOT a renamed BD file.',
             'create_bd_design design_1']
    for name, port in design.get('interface_ports', {}).items():
        lines.append('create_bd_intf_port -mode %s -vlnv %s %s' %
                     (q(port['mode']), q(port['vlnv']), q(name)))
    # This archive has only interface ports. Refuse a future schema silently
    # adding scalar ports until its width/direction handling is implemented.
    assert not design.get('ports')
    for name, cell in design['components'].items():
        if 'reference_info' in cell:
            lines.append('create_bd_cell -type module -reference %s %s' %
                         (q(cell['reference_info']['ref_name']), q(name)))
        else:
            vlnv = q(cell['vlnv'])
            lines.append('if {[llength [get_ipdefs -all %s]] != 1} {error %s}' %
                         (vlnv, q('Missing/ambiguous installed IP: ' + cell['vlnv'])))
            lines.append('create_bd_cell -type ip -vlnv %s %s' % (vlnv, q(name)))
        parameters = cell.get('parameters', {})
        if parameters:
            pairs = ' '.join(q('CONFIG.' + key) + ' ' + q(value['value'])
                             for key, value in parameters.items())
            lines.append('set_property -dict [list %s] [get_bd_cells %s]' % (pairs, q(name)))
    for kind, member, pin, port, command in [
        ('interface_nets', 'interface_ports', 'get_bd_intf_pins', 'get_bd_intf_ports', 'connect_bd_intf_net'),
        ('nets', 'ports', 'get_bd_pins', 'get_bd_ports', 'connect_bd_net'),
    ]:
        for name, net in design[kind].items():
            ends = ' '.join('[%s %s]' % (pin if '/' in end else port, q(end))
                            for end in net[member])
            lines.append('%s -%s %s %s' %
                         (command, 'intf_net' if kind == 'interface_nets' else 'net', q(name), ends))
    for name, cell in design['components'].items():
        for interface, config in cell.get('interface_ports', {}).items():
            for key, item in config.get('parameters', {}).items():
                if item.get('value_src') == 'user_prop':
                    lines.append('set_property %s %s [get_bd_intf_pins %s]' %
                                 (q('CONFIG.' + key), q(item['value']), q(name + '/' + interface)))
    for cell, addressing in design['addressing'].items():
        for space, config in addressing['address_spaces'].items():
            for name, segment in config['segments'].items():
                target = q(segment['address_block'])
                address_space = q(cell + '/' + space)
                lines.append('assign_bd_address -offset %s -range %s -target_address_space [get_bd_addr_spaces %s] [get_bd_addr_segs %s]' %
                             (q(segment['offset']), q(segment['range']), address_space, target))
                if segment.get('is_excluded', '').lower() == 'true':
                    # assign_bd_address already excludes this register region
                    # from a VDMA memory space. A second exclusion creates a
                    # duplicate 1-byte placeholder in Vivado 2020.1.
                    require(segment['address_block'].endswith('/HP1_LPS_OCM'),
                            'Unreviewed excluded address segment')
    lines.extend(['validate_bd_design', 'save_bd_design'])
    with destination.open('x', encoding='utf-8', newline='\n') as out:
        out.write('\n'.join(lines) + '\n')
    manifest = dict(source_bd_sha256=hashlib.sha256(bd.read_bytes()).hexdigest(),
                    source_tool='2020.2', target_tool='2020.1',
                    cells={name:dict(vlnv=c['vlnv'], parameters=c.get('parameters', {}))
                           for name, c in design['components'].items()},
                    addressing=design['addressing'], status='intent_only_not_implementation')
    with destination.with_suffix('.json').open('x', encoding='utf-8') as out:
        json.dump(manifest, out, indent=2)
        out.write('\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bd', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--audit', type=Path, help='Rebuilt BD to compare instead of emitting Tcl')
    args = parser.parse_args()
    if args.audit:
        audit(args.bd, args.audit, args.destination)
    else:
        emit(args.bd, args.destination)
