# Vivado 2020.2 -mode batch -source build.tcl -tclargs NEW_OUTPUT_DIR ?build|prepare?
# Source overlay: the camera archive, PS configuration and XDC remain unchanged.
if {$argc < 1 || $argc > 3} {error "usage: build.tcl NEW_OUTPUT_DIR ?build|prepare? ?compat2020.1?"}
set integration_compat [expr {$argc == 3 && [lindex $argv 2] eq "compat2020.1"}]
if {$argc == 3 && !$integration_compat} {error "Unknown adaptation profile"}
set integration_tool [version -short]
if {(!$integration_compat && $integration_tool ne "2020.2") || ($integration_compat && $integration_tool ne "2020.1")} {
    error "Use 2020.2 for the archive, or explicitly select compat2020.1 for source reconstruction."
}
set integration_root [file normalize [file dirname [info script]]]
set integration_output [file normalize [lindex $argv 0]]
set integration_mode [expr {$argc >= 2 ? [lindex $argv 1] : "build"}]
if {$integration_mode ni {build prepare}} {error "Unknown mode: $integration_mode"}
if {[file exists $integration_output]} {error "Output already exists: $integration_output"}

# Reuse the archived camera's reproducible creation entry point in a fresh directory.
set argc 1
set argv [list $integration_output]
if {$integration_compat} {
    source [file join $integration_root create_2020_1.tcl]
} else {
    source [file join $integration_root .. camera_hw scripts create_project.tcl]
}
set integration_bd [get_files */design_1.bd]
open_bd_design $integration_bd
foreach name {grasp_fsm.sv mujoco_axi_core.sv mjc1_axi_lite_top.v} {
    add_files -norecurse [file join $integration_root rtl $name]
}
update_compile_order -fileset sources_1

set integration_ps [get_bd_cells zynq_ultra_ps_e_0]
foreach {key expected} {
    PSU__USE__M_AXI_GP0 1 PSU__MAXIGP0__DATA_WIDTH 128
    PSU__SAXIGP3__DATA_WIDTH 128 PSU__FPGA_PL1_ENABLE 1
} {
    if {[get_property CONFIG.$key $integration_ps] != $expected} {
        error "Camera PS baseline differs: $key"
    }
}
if {abs([get_property CONFIG.PSU__CRL_APB__PL1_REF_CTRL__FREQMHZ $integration_ps] - 100.0) > 0.01} {
    error "MJC1 requires the existing 100 MHz PL1 profile"
}
set integration_space [get_bd_addr_spaces zynq_ultra_ps_e_0/Data]
set integration_original_segments {}
foreach segment [get_bd_addr_segs -of_objects $integration_space] {
    set offset [get_property OFFSET $segment]
    set range [get_property RANGE $segment]
    lappend integration_original_segments [list $segment $offset $range]
    if {$offset < 0xA0101000 && $offset + $range > 0xA0100000} {
        error "MJC1 overlaps a camera address segment: $segment"
    }
}
set integration_ports [lsort [get_bd_ports]]
set integration_interfaces [lsort [get_bd_intf_ports]]
if {[get_property CONFIG.NUM_MI [get_bd_cells ps8_0_axi_periph]] != 11} {
    error "Expected the reviewed camera interconnect with 11 existing masters"
}
set_property CONFIG.NUM_MI 12 [get_bd_cells ps8_0_axi_periph]
create_bd_cell -type module -reference mjc1_axi_lite_top mjc1
connect_bd_intf_net [get_bd_intf_pins ps8_0_axi_periph/M11_AXI] [get_bd_intf_pins mjc1/s_axi]

# Camera control uses PL0 (200 MHz), despite the old reset cell's 100M name.
# M11 uses a separate 100 MHz clock/reset; AXI Interconnect provides the CDC.
create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 rst_mjc1
set_property -dict [list CONFIG.C_EXT_RESET_HIGH 0 CONFIG.C_AUX_RESET_HIGH 0] [get_bd_cells rst_mjc1]
foreach {name value} {mjc1_zero 0 mjc1_one 1} {
    create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 $name
    set_property -dict [list CONFIG.CONST_WIDTH 1 CONFIG.CONST_VAL $value] [get_bd_cells $name]
}
connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk1] \
    [get_bd_pins ps8_0_axi_periph/M11_ACLK] [get_bd_pins mjc1/clk] [get_bd_pins rst_mjc1/slowest_sync_clk]
connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_resetn0] [get_bd_pins rst_mjc1/ext_reset_in]
connect_bd_net [get_bd_pins mjc1_zero/dout] [get_bd_pins rst_mjc1/mb_debug_sys_rst]
# Active-low auxiliary reset MUST be tied HIGH, otherwise AXI transactions hang.
connect_bd_net [get_bd_pins mjc1_one/dout] [get_bd_pins rst_mjc1/aux_reset_in] [get_bd_pins rst_mjc1/dcm_locked]
connect_bd_net [get_bd_pins rst_mjc1/peripheral_aresetn] [get_bd_pins mjc1/rst_n] [get_bd_pins ps8_0_axi_periph/M11_ARESETN]
assign_bd_address -target_address_space $integration_space [get_bd_addr_segs mjc1/s_axi/reg0] -offset 0xA0100000 -range 4K
validate_bd_design
if {[get_bd_nets -of_objects [get_bd_pins rst_mjc1/aux_reset_in]] ne [get_bd_nets -of_objects [get_bd_pins mjc1_one/dout]]} {
    error "MJC1 auxiliary reset is not deasserted"
}
foreach item $integration_original_segments {
    lassign $item segment offset range
    if {[get_property OFFSET [get_bd_addr_segs $segment]] != $offset || [get_property RANGE [get_bd_addr_segs $segment]] != $range} {
        error "Camera address changed: $segment"
    }
}
if {[lsort [get_bd_ports]] ne $integration_ports || [lsort [get_bd_intf_ports]] ne $integration_interfaces} {
    error "External camera ports changed"
}
save_bd_design
report_ip_status -file [file join $integration_output ip_status.rpt]
foreach ip [get_ips -all] {
    if {[get_property IS_LOCKED $ip]} {error "Locked IP requires matching tool/patch; no automatic upgrade: $ip"}
}
write_bd_tcl [file join $integration_output camera_mjc1_bd.tcl]
if {$integration_mode eq "prepare"} {
    puts "CAMERA_MJC1_BD_PREPARED_ONLY -- not a bitstream or board acceptance"
    close_project
    exit
}
generate_target all $integration_bd
update_compile_order -fileset sources_1
launch_runs synth_1 -jobs 2
wait_on_run synth_1
if {[get_property STATUS [get_runs synth_1]] ne "synth_design Complete!"} {error "Synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 2
wait_on_run impl_1
if {[get_property STATUS [get_runs impl_1]] ne "route_design Complete!"} {error "Implementation failed"}
open_run impl_1
report_drc -file [file join $integration_output drc.rpt]
report_timing_summary -report_unconstrained -file [file join $integration_output timing.rpt]
report_utilization -file [file join $integration_output utilization.rpt]
set integration_violations [get_drc_violations -quiet -filter {SEVERITY == Error}]
if {[llength $integration_violations]} {error "DRC errors: $integration_violations"}
foreach delay {max min} {
    set path [get_timing_paths -quiet -delay_type $delay -max_paths 1]
    if {![llength $path] || [get_property SLACK $path] < 0} {error "Timing $delay failed or unavailable"}
}
# Write only after the routed design passes these checks. Review unconstrained paths too.
# Let the implementation run own its bit so include_bit finds the matching artifact.
close_design
launch_runs impl_1 -to_step write_bitstream -jobs 2
wait_on_run impl_1
if {[get_property STATUS [get_runs impl_1]] ne "write_bitstream Complete!"} {error "Bitstream generation failed"}
open_run impl_1
file copy [file join [get_property DIRECTORY [get_runs impl_1]] design_1_wrapper.bit] [file join $integration_output camera_mjc1.bit]
write_hw_platform -fixed -include_bit [file join $integration_output camera_mjc1.xsa]
set integration_gate [open [file join $integration_output implementation_gate.json] w]
set integration_adaptation [expr {$integration_compat ? ",\"source_adaptation\":\"camera-intent-2020.1-v1\"" : ""}]
puts $integration_gate "\{\"profile\":\"camera-mjc1-v1\",\"tool\":\"$integration_tool\",\"implementation\":\"passed\",\"board_validation\":\"pending\",\"base\":2685403136,\"range\":4096$integration_adaptation\}"
close $integration_gate
set integration_bif [open [file join $integration_output camera_mjc1.bif] w]
puts $integration_bif "all:\n\{\n  \[destination_device=pl\] camera_mjc1.bit\n\}"
close $integration_bif
puts "CAMERA_MJC1_BUILD_COMPLETE -- board concurrency acceptance still required"
close_project
exit
