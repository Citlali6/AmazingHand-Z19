# Explicit, user-authorized source adaptation. Never edits the supplier archive.
if {[version -short] ne "2020.1"} {error "This adapter targets Vivado 2020.1 only"}
set output_dir $integration_output
set archive_dir [file normalize [file join $integration_root .. camera_hw project]]
file mkdir $output_dir
file copy $archive_dir [file join $output_dir source]
set source_dir [file join $output_dir source]
set intent [file join $output_dir camera_2020_1_intent.tcl]
# Vivado sets PYTHONHOME to its bundled Python 2; do not inherit that in Python 3.
exec python -E [file join $integration_root adapt_2020_1.py] \
    [file join $source_dir mipi_dp.srcs sources_1 bd design_1 design_1.bd] $intent
create_project mipi_dp [file join $output_dir vivado] -part xczu19eg-ffvc1760-2-i
set_property ip_repo_paths [list [file join $source_dir repo]] [current_project]
update_ip_catalog
foreach relative {
    mipi_dp.srcs/sources_1/new/axis_pixel_counter.v
    import/pipeline_latency_timer.v
    mipi_dp.srcs/sources_1/new/frame_ptr_trigger.v
    import/frame_event_counter.v
    mipi_dp.srcs/sources_1/new/bus_sync.v
} {add_files -norecurse [file join $source_dir $relative]}
foreach relative {system.xdc mipi.xdc QSFP.xdc ddr4_set.xdc mipi2.xdc} {
    add_files -fileset constrs_1 -norecurse [file join $source_dir mipi_dp.srcs constrs_1 new $relative]
}
update_compile_order -fileset sources_1
source -notrace $intent
set camera_bd [get_files */design_1.bd]
puts [exec python -E [file join $integration_root adapt_2020_1.py] \
    [file join $source_dir mipi_dp.srcs sources_1 bd design_1 design_1.bd] \
    [file join $output_dir adaptation_audit.json] --audit $camera_bd]
add_files -norecurse [make_wrapper -files $camera_bd -top]
set_property top design_1_wrapper [get_filesets sources_1]
update_compile_order -fileset sources_1
