"""Hash a completed composite build for manual bench deployment, never a camera-only bit."""
import argparse
import hashlib
import json
from pathlib import Path


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('build', type=Path)
    args = parser.parse_args()
    root = args.build.resolve()
    gate = json.loads((root / 'implementation_gate.json').read_text())
    tool = gate.get('tool')
    expected = {'profile': 'camera-mjc1-v1', 'tool': tool,
                'implementation': 'passed', 'board_validation': 'pending',
                'base': 0xA0100000, 'range': 4096}
    if tool == '2020.1':
        expected['source_adaptation'] = 'camera-intent-2020.1-v1'
    if tool not in ('2020.1', '2020.2') or gate != expected:
        raise RuntimeError('No matching completed implementation gate')
    artifacts = ['camera_mjc1.bit', 'camera_mjc1.bit.bin', 'camera_mjc1.xsa',
                 'drc.rpt', 'timing.rpt', 'utilization.rpt', 'ip_status.rpt',
                 'camera_mjc1_bd.tcl']
    if tool == '2020.1':
        audit = json.loads((root / 'adaptation_audit.json').read_text())
        if audit.get('intent_audit') != 'passed' or audit.get('profile') != expected['source_adaptation']:
            raise RuntimeError('Source adaptation audit missing or failed')
        artifacts += ['adaptation_audit.json', 'camera_2020_1_intent.tcl', 'camera_2020_1_intent.json']
    hashes = {name: sha256(root / name) for name in artifacts}
    profile = dict(gate, hashes=hashes)
    # No overwrite: preserve every previous deployment manifest.
    with (root / 'deployment.json').open('x', encoding='utf-8') as out:
        json.dump(profile, out, indent=2)
        out.write('\n')
    print('COMPOSITE_PACKAGE_READY_FOR_BENCH; concurrent camera/PL acceptance PENDING')


if __name__ == '__main__':
    main()
