# Existing MJC1 regression; independent of the camera's 2020.2 IP generation.
# xvlog/xelab/xsim run in NEW_OUTPUT_DIR, never in the source tree.
if {$argc != 1} {error "usage: run.tcl NEW_OUTPUT_DIR"}
set root [file normalize [file join [file dirname [info script]] ..]]
set output [file normalize [lindex $argv 0]]
if {[file exists $output]} {error "Output already exists: $output"}
file mkdir $output
cd $output
set bin [file normalize [file join [file dirname [info nameofexecutable]] ../..]]
exec [file join $bin xvlog.bat] -sv [file join $root rtl grasp_fsm.sv] [file join $root rtl mujoco_axi_core.sv] [file join $root rtl mjc1_axi_lite_top.v] [file join $root sim tb_mujoco_axi_core.sv] > compile.txt 2>@1
exec [file join $bin xelab.bat] tb_mujoco_axi_core -s mjc1_test > elaborate.txt 2>@1
exec [file join $bin xsim.bat] mjc1_test -runall > simulation.txt 2>@1
set result [open simulation.txt r]
set content [read $result]
close $result
if {![string match *MJC1_CORE_PASS* $content] || [regexp {Fatal:|Error:} $content]} {
    error "MJC1 regression failed; inspect $output/simulation.txt"
}
puts "MJC1_REGRESSION_PASS"
exit
