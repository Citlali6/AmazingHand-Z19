# 相机 + MJC1 板端原生访问

**配套集成固件尚未生成，以下部署步骤待完整构建后执行。** 不要对当前板卡运行探测；它仍是旧地址的 MJC1-only profile。
本目录只针对 Z19 AArch64 / Linux5.4.0-xilinx-v2020.2，不在 Windows 编译或安装板端依赖。

## 程序

- `mmio.c`：只提供32位 volatile MMIO与dmb/dsb屏障的共享库；没有无保护的独立探测入口。
- `load_composite.py`：检查构建manifest/rawhash、原camera module hash/ABI、clock、PS接口、driver及MMIO占用；只向易失FPGA加载固件，不改SD启动。核对MJC1/1.2/CMJ1后加载相机module，写入本次boot的`/run/amazinghand/camera-mjc1.json`。
- `board_loop.py`：必须先有匹配receipt；共享profile锁防reload、排他控制锁防重复客户端；读真实PL目标，发送MuJoCo，写回反馈并逐帧比对ACK。没有软件FSM替代。

## 构建后手动部署

保留当前camera-only与MJC1-only包作为回退。在新的板端版本目录部署本目录三个源码、`deployment.json`、匹配raw bin；沿用已验证相机module和预览程序。
先验证并停止旧MJC1进程、停止相机采集与server、卸载`ah_camera0`。加载器不替用户强杀进程。
在板端新目录：

```sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
gcc -O2 -Wall -Wextra -Werror -fPIC -shared mmio.c -o libmjc_mmio.so
python3 load_composite.py /lib/firmware/amazinghand-camera-mjc1-VERSION.bin ./deployment.json /opt/amazinghand/camera0-linux-hd-20261010/ah_camera0.ko
python3 -u board_loop.py --probe
```

固件只能使用本次构建和报告对应的hash。首次PL读取仍依赖正确硬件连线；软件超时不能保证恢复不响应AXI事务。
若加载失败，不要启动采集或随意换地址探测，保留日志排查。

## 同时运行

PC现有MuJoCo observer继续监听127.0.0.1:8765；SSH会话保持反向转发`127.0.0.1:18765:127.0.0.1:8765`。
在板端（已probe成功后）：

```sh
python3 -u board_loop.py --pc 127.0.0.1 --port 18765 --seconds 3600
```

另一个SSH启动现有`/opt/amazinghand/camera0-linux-hd-20261010/start_preview.py`；PC现有`host/camera_linux/view_camera.py`提供8766页面。
**不要再运行camera-only或MJC1-only loader**，它们都会替换整片PL。
停止相机采集不重配PL，因此集成成功后虚拟手连接可保持；这项并发行为目前尚待上板验收。

程序不改密码、不保存凭据、不调整防火墙，也不自动重启或写boot存储。
