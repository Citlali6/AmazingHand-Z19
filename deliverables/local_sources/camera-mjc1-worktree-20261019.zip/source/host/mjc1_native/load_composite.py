"""Manual, volatile composite-image loader. Stops on busy users; never kills them.

Use only after reviewing matching BD/IP, DRC, timing and any adaptation reports.
No boot files, PS clocks, AFI widths or device-tree nodes are rewritten.
"""
import argparse
import ctypes
import fcntl
import hashlib
import json
import mmap
import os
from pathlib import Path
import platform
import subprocess

RUN = Path('/run/amazinghand')
RECEIPT = RUN / 'camera-mjc1.json'
DRIVER_HASH = '56bc43d3153ed861a598293ea7d38920806107c1ec8eaac4b70eeb87f62fe368'


def require(value, detail):
    if not value:
        raise RuntimeError('COMPOSITE_LOAD_REFUSED: ' + detail)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('firmware', type=Path)
    parser.add_argument('deployment', type=Path)
    parser.add_argument('module', type=Path)
    args = parser.parse_args()
    require(os.geteuid() == 0 and platform.machine() == 'aarch64', 'Z19 root required')
    require(platform.release() == '5.4.0-xilinx-v2020.2', 'kernel profile mismatch')
    firmware, module = args.firmware.resolve(), args.module.resolve()
    require(firmware.parent == Path('/lib/firmware') and firmware.suffix == '.bin', 'firmware must be /lib/firmware/NAME.bin')
    profile = json.loads(args.deployment.read_text())
    require(profile.get('profile') == 'camera-mjc1-v1' and profile.get('tool') in ('2020.1', '2020.2')
            and profile.get('implementation') == 'passed' and profile.get('base') == 0xA0100000
            and profile.get('range') == 4096, 'not a matching composite implementation')
    if profile['tool'] == '2020.1':
        require(profile.get('source_adaptation') == 'camera-intent-2020.1-v1'
                and 'adaptation_audit.json' in profile['hashes'], 'adaptation identity/audit missing')
    require(digest(firmware) == profile['hashes']['camera_mjc1.bit.bin'], 'firmware hash mismatch')
    require(digest(module) == DRIVER_HASH, 'not the reviewed camera module')
    require(subprocess.check_output(['modinfo', '-F', 'vermagic', str(module)], universal_newlines=True).strip()
            == '5.4.0-xilinx-v2020.2 SMP mod_unload aarch64', 'module ABI mismatch')
    RUN.mkdir(exist_ok=True)
    with (RUN / 'pl-profile.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(not Path('/sys/module/ah_camera0').exists(), 'stop camera and unload ah_camera0 first')
        require(not Path('/dev/mipi_cam').exists(), 'another camera driver is present')
        require(Path('/dev/i2c-0').exists(), 'PS I2C0 missing')
        for path in Path('/sys/bus/platform/devices').glob('a0*'):
            require(not (path / 'driver').exists(), 'active PL driver: ' + str(path))
        # Detect old control clients too: they do not participate in the new lock.
        for path in Path('/proc').glob('[0-9]*/maps'):
            try:
                lines = path.read_text().splitlines()
            except (FileNotFoundError, ProcessLookupError):
                continue
            for line in lines:
                columns = line.split()
                if len(columns) >= 6 and columns[-1] == '/dev/mem':
                    offset = int(columns[2], 16)
                    size = int(columns[0].split('-')[1], 16) - int(columns[0].split('-')[0], 16)
                    require(not (offset < 0xA0110000 and offset + size > 0xA0000000), 'active PL MMIO owner: ' + str(path))
        clocks = {}
        for line in Path('/sys/kernel/debug/clk/clk_summary').read_text().splitlines():
            values = line.split()
            if values and values[0] in ('pl0_ref', 'pl1_ref'):
                clocks[values[0]] = (int(values[1]), int(values[4]))
        for name, low, high in [('pl0_ref', 198000000, 202000000), ('pl1_ref', 99000000, 101000000)]:
            require(name in clocks and clocks[name][0] >= 1 and low <= clocks[name][1] <= high, 'unexpected clock: ' + name)
        io = ctypes.CDLL(str(Path(__file__).resolve().with_name('libmjc_mmio.so')))
        io.mjc_read32.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        io.mjc_read32.restype = ctypes.c_uint32
        fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
        try:
            # Only known PS registers are read before loading the matching PL.
            for address, mask, expected in [(0xFD615000, 0x300, 0x200),
                                            (0xFD390000, 3, 0), (0xFD390014, 3, 0),
                                            (0xFD1A0100, 0x1f80, 0)]:
                with mmap.mmap(fd, 4096, access=mmap.ACCESS_WRITE, offset=address & ~4095) as registers:
                    pointer = ctypes.addressof(ctypes.c_char.from_buffer(registers))
                    require(io.mjc_read32(pointer, address & 4095) & mask == expected, 'PS interface mismatch at %#x' % address)
            if RECEIPT.exists():
                RECEIPT.unlink()  # Invalidate our prior runtime receipt before programming.
            manager = Path('/sys/class/fpga_manager/fpga0')
            (manager / 'flags').write_text('0')
            (manager / 'firmware').write_text(firmware.name)
            require((manager / 'state').read_text().strip() == 'operating', 'FPGA programming incomplete')
            with mmap.mmap(fd, 4096, access=mmap.ACCESS_WRITE, offset=0xA0100000) as registers:
                pointer = ctypes.addressof(ctypes.c_char.from_buffer(registers))
                require([io.mjc_read32(pointer, offset) for offset in (0, 4, 0x48)]
                        == [0x31434A4D, 0x10002, 0x434D4A31], 'MJC1 identity/version/profile mismatch')
            subprocess.run(['insmod', str(module), 'matched_pl=1'], check=True)
            require(Path('/dev/ah_camera0').is_char_device(), 'camera device missing')
            receipt = dict(profile='camera-mjc1-v1', base=0xA0100000,
                           boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                           firmware=firmware.name, sha256=digest(firmware))
            RECEIPT.write_text(json.dumps(receipt) + '\n')
        finally:
            os.close(fd)
    print('COMPOSITE_LOADED: camera module + CMJ1; concurrency acceptance still required')


if __name__ == '__main__':
    main()
