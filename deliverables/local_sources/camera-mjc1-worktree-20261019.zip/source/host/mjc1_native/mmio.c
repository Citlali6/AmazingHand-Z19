/* Native AArch64 MMIO: full 32-bit accesses with explicit device barriers. */
#include <stdint.h>
#include <stdlib.h>
#ifndef __aarch64__
#error "Build this file on the AArch64 Z19 board"
#endif

uint32_t mjc_read32(void *base, uint32_t offset) {
    if ((offset & 3) || offset > 4092) abort();
    __asm__ volatile("dmb sy" ::: "memory");
    uint32_t result = *(volatile uint32_t *)((char *)base + offset);
    __asm__ volatile("dsb sy" ::: "memory");
    return result;
}

void mjc_write32(void *base, uint32_t offset, uint32_t value) {
    if ((offset & 3) || offset > 4092) abort();
    __asm__ volatile("dmb sy" ::: "memory");
    *(volatile uint32_t *)((char *)base + offset) = value;
    __asm__ volatile("dsb sy" ::: "memory");
}

