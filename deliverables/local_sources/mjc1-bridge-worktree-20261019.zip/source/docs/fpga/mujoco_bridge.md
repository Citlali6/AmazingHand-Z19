# FPGA → MuJoCo 观察式闭环

## 目标

MJC1 是独立的虚拟验证固件。Zynq PS 只负责把 FPGA 当前 FSM 输出转发给 PC；PC 上游 AmazingHand MuJoCo 模型执行目标并返回实际关节位置。返回的位置和虚拟负载进入 MJC1 反馈寄存器，由 FPGA 的 `grasp_fsm.sv` 决定后续状态和目标。此镜像不连接舵机 UART，也没有物理舵机输出。

```text
grasp_fsm.sv → MJC1 AXI → Zynq PS → TCP → MuJoCo 模型/观察窗
      ↑                                          ↓
      └──────── PS 提交位置与虚拟负载反馈 ────────┘
```

## PC 观察端

Windows PC 安装 Python 3.10+ 和 MuJoCo Python 包（`pip install -r requirements-mujoco.txt`），在仓库根目录启动 `sim/start_observer.bat`。也可以在终端运行：

```powershell
python sim/mujoco_observer.py --bind 0.0.0.0 --port 8765
```

脚本打开手部窗口并等待板端 PS 连接。连接后自动展示预张、闭合、保持、释放；每次 FPGA 状态变化也打印到启动窗口。闭环结束后窗口仍保持打开，便于观察最终姿态。需要让 PC 与 Z19 位于同一可达网络，并允许 TCP 8765 入站。

## 板端 PS

用 `fpga/scripts/build_mujoco_system.tcl` 生成 MJC1 bitstream/XSA。启动板端 Linux 后，先只读确认烧录的是 MJC1 镜像：

```sh
sudo python3 -m app.control.mujoco_closed_loop --probe
```

把仓库 `host/` 目录复制到板端，进入该目录后启动演示：

```sh
sudo python3 -m app.control.mujoco_closed_loop --pc <PC_IP> --port 8765
```

板端脚本自动设置安全的虚拟演示目标，启动 FPGA 状态机，轮询 FPGA 当前目标，回送 MuJoCo 的位置/负载并在 HOLD 后自动释放。正常使用不需要键盘或命令输入；PC 窗口是观察界面。Ctrl+C 可结束板端程序。`--probe` 不写寄存器，演示模式只允许在已加载 MJC1 专用镜像时启动。

## 寄存器与编码

基地址为 `0x8000_0000`，AXI4-Lite 32 位。ID `0x000` 必须为 `0x31434a4d`（小端字节 MJC1），版本在 `0x004`。控制/命令分别位于 `0x008/0x00c`；FSM 实际输出目标为 `0x050..0x06c`，状态为 `0x040`；反馈暂存区为 `0x080..0x09c`，提交序号为 `0x0a0`，已接受序号为 `0x044`。

虚拟 raw 角度编码为 `raw = round(deg × 10) + 900`，范围 0..1800 对应 -90°..+90°。反馈寄存器 `[11:0]` 为实测虚拟位置，`[21:12]` 为 MuJoCo 执行器力的缩放显示值。这个 load 仅供闭环流程验证，不能当成 SCS0009 负载或真实抓取力。

## 可复现 RTL 验证

Vivado 2020.1：

```powershell
New-Item -ItemType Directory -Force fpga/build/out/mujoco_core_verify | Out-Null
Set-Location fpga/build/out/mujoco_core_verify
& D:/Vivado/Vivado/2020.1/bin/xvlog.bat -sv ../../../rtl/grasp_fsm.sv ../../../rtl/mujoco_axi_core.sv ../../../sim/tb_mujoco_axi_core.sv
& D:/Vivado/Vivado/2020.1/bin/xelab.bat tb_mujoco_axi_core -s tb_mujoco_axi_core_sim
& D:/Vivado/Vivado/2020.1/bin/xsim.bat tb_mujoco_axi_core_sim -runall
```

通过标记为 `MJC1_CORE_PASS`。MuJoCo 模型与 TCP 反馈可在无板条件下检查：

```powershell
sim/.venv_mjc/Scripts/python.exe tools/verify_mujoco_observer.py
```

现有 FSM 状态测试单独运行 `tb_grasp_fsm`。完整板端链路仍需把该 MJC1 bitstream 加载到 XCZU19EG 并由板端 Linux 运行上述客户端；PC RTL 仿真和生成 bitstream 都不能代替这一步实板确认。
