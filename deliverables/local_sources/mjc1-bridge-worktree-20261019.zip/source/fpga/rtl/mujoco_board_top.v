// AXI4 (PS HPM0_LPD) to AXI4-Lite (MJC1) single-beat bridge.
// Linux /dev/mem accesses are 32-bit single transfers. Bursts are rejected.
module mujoco_board_top (
    input wire clk, input wire peripheral_aresetn,
    input wire [15:0] s_axi_awid, input wire [39:0] s_axi_awaddr,
    input wire [7:0] s_axi_awlen, input wire [2:0] s_axi_awsize,
    input wire [1:0] s_axi_awburst, input wire s_axi_awlock,
    input wire [3:0] s_axi_awcache, input wire [2:0] s_axi_awprot,
    input wire [3:0] s_axi_awqos, input wire [15:0] s_axi_awuser,
    input wire s_axi_awvalid, output wire s_axi_awready,
    input wire [31:0] s_axi_wdata, input wire [3:0] s_axi_wstrb,
    input wire s_axi_wlast,
    input wire s_axi_wvalid, output wire s_axi_wready,
    output reg [15:0] s_axi_bid, output reg [1:0] s_axi_bresp,
    output reg s_axi_bvalid, input wire s_axi_bready,
    input wire [15:0] s_axi_arid, input wire [39:0] s_axi_araddr,
    input wire [7:0] s_axi_arlen, input wire [2:0] s_axi_arsize,
    input wire [1:0] s_axi_arburst, input wire s_axi_arlock,
    input wire [3:0] s_axi_arcache, input wire [2:0] s_axi_arprot,
    input wire [3:0] s_axi_arqos, input wire [15:0] s_axi_aruser,
    input wire s_axi_arvalid, output wire s_axi_arready,
    output reg [15:0] s_axi_rid, output reg [31:0] s_axi_rdata,
    output reg [1:0] s_axi_rresp, output reg s_axi_rlast,
    output reg s_axi_rvalid, input wire s_axi_rready
);
    localparam [1:0] W_CAPTURE=0, W_SEND=1, W_WAIT=2, W_OUT=3;
    localparam [1:0] R_IDLE=0, R_SEND=1, R_WAIT=2, R_OUT=3;
    reg [1:0] wstate, rstate;
    reg aw_have, w_have, aw_done, w_done, bad_write;
    reg [15:0] awid_q;
    reg [11:0] awaddr_q;
    reg [31:0] wdata_q;
    reg [3:0] wstrb_q;
    reg [15:0] arid_q;
    reg [11:0] araddr_q;
    reg bad_read;
    wire core_awready, core_wready, core_bvalid;
    wire [1:0] core_bresp;
    wire core_arready, core_rvalid;
    wire [31:0] core_rdata;
    wire [1:0] core_rresp;
    reg core_awvalid, core_wvalid, core_bready;
    reg core_arvalid, core_rready;

    assign s_axi_awready = (wstate==W_CAPTURE) && !aw_have;
    assign s_axi_wready  = (wstate==W_CAPTURE) && !w_have;
    assign s_axi_arready = (rstate==R_IDLE);

    always @* begin
        core_awvalid = (wstate==W_SEND) && !aw_done;
        core_wvalid  = (wstate==W_SEND) && !w_done;
        core_bready  = (wstate==W_WAIT);
        core_arvalid = (rstate==R_SEND);
        core_rready  = (rstate==R_WAIT);
    end

    mujoco_axi_core u_core (
        .clk(clk), .rst_n(peripheral_aresetn),
        .s_axi_awaddr(awaddr_q), .s_axi_awvalid(core_awvalid), .s_axi_awready(core_awready),
        .s_axi_wdata(wdata_q), .s_axi_wstrb(wstrb_q), .s_axi_wvalid(core_wvalid), .s_axi_wready(core_wready),
        .s_axi_bresp(core_bresp), .s_axi_bvalid(core_bvalid), .s_axi_bready(core_bready),
        .s_axi_araddr(araddr_q), .s_axi_arvalid(core_arvalid), .s_axi_arready(core_arready),
        .s_axi_rdata(core_rdata), .s_axi_rresp(core_rresp), .s_axi_rvalid(core_rvalid), .s_axi_rready(core_rready)
    );

    always @(posedge clk or negedge peripheral_aresetn) begin
        if (!peripheral_aresetn) begin
            wstate<=W_CAPTURE; aw_have<=0; w_have<=0; aw_done<=0; w_done<=0;
            bad_write<=0; awid_q<=0; awaddr_q<=0; wdata_q<=0; wstrb_q<=0;
            s_axi_bid<=0; s_axi_bresp<=0; s_axi_bvalid<=0;
        end else begin
            if (wstate==W_CAPTURE) begin
                if (s_axi_awvalid && s_axi_awready) begin
                    aw_have<=1; awid_q<=s_axi_awid; awaddr_q<=s_axi_awaddr[11:0];
                    bad_write <= (s_axi_awlen!=0) || (s_axi_awsize!=3'b010) ||
                                 (s_axi_awburst==2'b10);
                end
                if (s_axi_wvalid && s_axi_wready) begin
                    w_have<=1; wdata_q<=s_axi_wdata; wstrb_q<=s_axi_wstrb;
                    if (!s_axi_wlast) bad_write<=1;
                end
                if ((aw_have || (s_axi_awvalid && s_axi_awready)) &&
                    (w_have || (s_axi_wvalid && s_axi_wready))) begin
                    aw_have<=0; w_have<=0; s_axi_bid<=aw_have ? awid_q : s_axi_awid;
                    if (bad_write || (s_axi_awvalid && s_axi_awready &&
                        ((s_axi_awlen!=0)||(s_axi_awsize!=3'b010)||(s_axi_awburst==2'b10))) ||
                        (s_axi_wvalid && s_axi_wready && !s_axi_wlast)) begin
                        s_axi_bresp<=2'b10; s_axi_bvalid<=1; wstate<=W_OUT;
                    end else begin aw_done<=0; w_done<=0; wstate<=W_SEND; end
                end
            end else if (wstate==W_SEND) begin
                if (core_awvalid && core_awready) aw_done<=1;
                if (core_wvalid && core_wready) w_done<=1;
                if ((aw_done || (core_awvalid && core_awready)) &&
                    (w_done || (core_wvalid && core_wready))) wstate<=W_WAIT;
            end else if (wstate==W_WAIT && core_bvalid) begin
                s_axi_bresp<=core_bresp; s_axi_bvalid<=1; wstate<=W_OUT;
            end else if (wstate==W_OUT && s_axi_bvalid && s_axi_bready) begin
                s_axi_bvalid<=0; wstate<=W_CAPTURE;
            end
        end
    end

    always @(posedge clk or negedge peripheral_aresetn) begin
        if (!peripheral_aresetn) begin
            rstate<=R_IDLE; arid_q<=0; araddr_q<=0; bad_read<=0;
            s_axi_rid<=0; s_axi_rdata<=0; s_axi_rresp<=0; s_axi_rlast<=0; s_axi_rvalid<=0;
        end else begin
            if (rstate==R_IDLE && s_axi_arvalid && s_axi_arready) begin
                arid_q<=s_axi_arid; araddr_q<=s_axi_araddr[11:0]; s_axi_rid<=s_axi_arid;
                bad_read <= (s_axi_arlen!=0) || (s_axi_arsize!=3'b010) || (s_axi_arburst==2'b10);
                if ((s_axi_arlen!=0) || (s_axi_arsize!=3'b010) || (s_axi_arburst==2'b10)) begin
                    s_axi_rdata<=0; s_axi_rresp<=2'b10; s_axi_rlast<=1; s_axi_rvalid<=1; rstate<=R_OUT;
                end else rstate<=R_SEND;
            end else if (rstate==R_SEND && core_arready) rstate<=R_WAIT;
            else if (rstate==R_WAIT && core_rvalid) begin
                s_axi_rdata<=core_rdata; s_axi_rresp<=core_rresp; s_axi_rlast<=1;
                s_axi_rvalid<=1; rstate<=R_OUT;
            end else if (rstate==R_OUT && s_axi_rvalid && s_axi_rready) begin
                s_axi_rvalid<=0; s_axi_rlast<=0; rstate<=R_IDLE;
            end
        end
    end
endmodule
