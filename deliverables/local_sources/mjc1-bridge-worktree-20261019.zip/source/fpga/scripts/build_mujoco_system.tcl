# Build the virtual-only MJC1 PS/PL image for the ALINX Z19 (XCZU19EG).
# Run: vivado -mode batch -source fpga/scripts/build_mujoco_system.tcl
set script_dir [file normalize [file dirname [info script]]]
set repo_root  [file normalize [file join $script_dir ../..]]
set out_dir    [file join $repo_root fpga build out mujoco_board]
set rtl_dir    [file join $repo_root fpga rtl]
set part       xczu19eg-ffvc1760-2-i
file mkdir $out_dir
cd $out_dir
create_project -force mujoco_board [file join $out_dir project] -part $part
add_files -norecurse [list [file join $rtl_dir grasp_fsm.sv] [file join $rtl_dir mujoco_axi_core.sv] [file join $rtl_dir mujoco_board_top.v]]
set_property top mujoco_board_top [current_fileset]
update_compile_order -fileset sources_1

create_bd_design mujoco_bd
create_bd_cell -type ip -vlnv xilinx.com:ip:zynq_ultra_ps_e:3.3 ps0
source [file join $script_dir alinx ps_config.tcl]
set_ps_config ps0
set_property -dict [list \
    CONFIG.PSU__USE__M_AXI_GP2 {1} \
    CONFIG.PSU__FPGA_PL0_ENABLE {1} \
    CONFIG.PSU__CRL_APB__PL0_REF_CTRL__FREQMHZ {100.000} \
] [get_bd_cells ps0]
create_bd_cell -type module -reference mujoco_board_top mjc1

if {[llength [get_bd_intf_pins -quiet mjc1/s_axi]] == 0} {
    error "Vivado did not infer mjc1/s_axi; inspect AXI port names in mujoco_axi_core.sv"
}
create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 rst_ps
create_bd_cell -type ip -vlnv xilinx.com:ip:util_vector_logic:2.0 reset_inv
set_property -dict [list CONFIG.C_OPERATION {not} CONFIG.C_SIZE {1}] [get_bd_cells reset_inv]
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 aux_reset_zero
set_property -dict [list CONFIG.CONST_WIDTH {1} CONFIG.CONST_VAL {0}] [get_bd_cells aux_reset_zero]
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 debug_reset_zero
set_property -dict [list CONFIG.CONST_WIDTH {1} CONFIG.CONST_VAL {0}] [get_bd_cells debug_reset_zero]
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 dcm_locked_one
set_property -dict [list CONFIG.CONST_WIDTH {1} CONFIG.CONST_VAL {1}] [get_bd_cells dcm_locked_one]
connect_bd_intf_net [get_bd_intf_pins ps0/M_AXI_HPM0_LPD] [get_bd_intf_pins mjc1/s_axi]
connect_bd_net [get_bd_pins ps0/pl_clk0] [get_bd_pins mjc1/clk]
connect_bd_net [get_bd_pins ps0/maxihpm0_lpd_aclk] [get_bd_pins ps0/pl_clk0]
connect_bd_net [get_bd_pins ps0/pl_clk0] [get_bd_pins rst_ps/slowest_sync_clk]
connect_bd_net [get_bd_pins ps0/pl_resetn0] [get_bd_pins reset_inv/Op1]
connect_bd_net [get_bd_pins reset_inv/Res] [get_bd_pins rst_ps/ext_reset_in]
connect_bd_net [get_bd_pins aux_reset_zero/dout] [get_bd_pins rst_ps/aux_reset_in]
connect_bd_net [get_bd_pins debug_reset_zero/dout] [get_bd_pins rst_ps/mb_debug_sys_rst]
connect_bd_net [get_bd_pins dcm_locked_one/dout] [get_bd_pins rst_ps/dcm_locked]
connect_bd_net [get_bd_pins rst_ps/peripheral_aresetn] [get_bd_pins mjc1/peripheral_aresetn]
set seg [lindex [get_bd_addr_segs -quiet mjc1/s_axi/*] 0]
if {$seg eq ""} { error "No AXI address segment inferred for MJC1" }
assign_bd_address -target_address_space /ps0/Data $seg -offset 0x80000000 -range 4K
regenerate_bd_layout
validate_bd_design
save_bd_design

set bd_file [get_files -quiet [file join $out_dir project project.srcs sources_1 bd mujoco_bd mujoco_bd.bd]]
if {$bd_file eq ""} { set bd_file [get_files -quiet */mujoco_bd.bd] }
make_wrapper -files $bd_file -top
set wrapper [glob [file join $out_dir project mujoco_board.srcs sources_1 bd mujoco_bd hdl mujoco_bd_wrapper.v]]
add_files -norecurse $wrapper
set_property top mujoco_bd_wrapper [current_fileset]
update_compile_order -fileset sources_1
generate_target all $bd_file
launch_runs synth_1 -jobs 2
wait_on_run synth_1
if {[get_property STATUS [get_runs synth_1]] ne "synth_design Complete!"} {
    error "Synthesis did not complete: [get_property STATUS [get_runs synth_1]]"
}
launch_runs impl_1 -to_step write_bitstream -jobs 2
wait_on_run impl_1
if {[get_property STATUS [get_runs impl_1]] ne "write_bitstream Complete!"} {
    error "Implementation/bitstream did not complete: [get_property STATUS [get_runs impl_1]]"
}
open_run impl_1
report_drc -file [file join $out_dir mujoco_drc.rpt]
report_timing_summary -file [file join $out_dir mujoco_timing.rpt]
write_hw_platform -fixed -include_bit -force [file join $out_dir mujoco_board.xsa]
puts "MJC1 BUILD OK"
puts "BIT: [get_property DIRECTORY [get_runs impl_1]]/mujoco_bd_wrapper.bit"
puts "XSA: [file join $out_dir mujoco_board.xsa]"
