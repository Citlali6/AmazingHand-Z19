"""MJC1 PS bridge: actual FPGA FSM targets <-> PC MuJoCo over TCP."""
from __future__ import annotations

import argparse
import json
import mmap
import socket
import struct
import time

BASE = 0x80000000
REG = {"id": 0x000, "version": 0x004, "ctrl": 0x008, "cmd": 0x00C,
       "torque": 0x030, "speed": 0x034, "status": 0x040, "seq": 0x044,
       "target": 0x050, "feedback": 0x080, "commit": 0x0A0}
SIGNATURE = 0x31434A4D
STATE = {0: "IDLE", 1: "PREGRASP", 2: "CLOSING", 3: "HOLD", 4: "RELEASING", 5: "PROTECT"}


class RegisterMap:
    def __init__(self, device: str, base: int):
        self.fd = open(device, "r+b", buffering=0)
        # The PS/PL AXI window is 4 KiB. Map one OS page so this also works
        # on Linux systems whose page size is larger than the AXI window.
        self.mem = mmap.mmap(self.fd.fileno(), mmap.PAGESIZE, access=mmap.ACCESS_WRITE,
                             offset=base & ~(mmap.PAGESIZE - 1))
        self.offset = base & (mmap.PAGESIZE - 1)

    def read(self, offset: int) -> int:
        return struct.unpack_from("<I", self.mem, self.offset + offset)[0]

    def write(self, offset: int, value: int) -> None:
        struct.pack_into("<I", self.mem, self.offset + offset, value & 0xFFFFFFFF)

    def close(self) -> None:
        self.mem.close()
        self.fd.close()


def recv_line(sock: socket.socket, buffer: bytearray) -> dict:
    while b"\n" not in buffer:
        chunk = sock.recv(4096)
        if not chunk:
            raise ConnectionError("MuJoCo observer disconnected")
        buffer.extend(chunk)
        if len(buffer) > 65536:
            raise ValueError("oversized MuJoCo response")
    line, _, tail = buffer.partition(b"\n")
    buffer[:] = tail
    obj = json.loads(line)
    if not isinstance(obj, dict):
        raise ValueError("MuJoCo response must be an object")
    return obj


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the FPGA-to-MuJoCo observer loop on Z19 Linux")
    ap.add_argument("--probe", action="store_true", help="read only MJC1 ID/version; no writes")
    ap.add_argument("--device", default="/dev/mem")
    ap.add_argument("--base", type=lambda x: int(x, 0), default=BASE)
    ap.add_argument("--pc", help="PC IPv4 address running sim/mujoco_observer.py")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--period", type=float, default=0.02)
    ap.add_argument("--hold-seconds", type=float, default=1.0)
    args = ap.parse_args()
    if not args.probe and not args.pc:
        ap.error("--pc is required unless using --probe")
    if not 0.005 <= args.period <= 0.1:
        ap.error("--period must be between 5 ms and 100 ms")

    regs = RegisterMap(args.device, args.base)
    try:
        ident, version = regs.read(REG["id"]), regs.read(REG["version"])
        if ident != SIGNATURE:
            raise RuntimeError(f"wrong FPGA image ID 0x{ident:08x}; expected MJC1 0x{SIGNATURE:08x}")
        print(f"FPGA MJC1 OK, version {version >> 16}.{version & 0xffff}")
        if args.probe:
            return 0
        with socket.create_connection((args.pc, args.port), timeout=5.0) as sock:
            sock.settimeout(2.0)
            sock_file = sock.makefile("rwb", buffering=0)
            seq = 0
            state_prev = -1
            hold_started = None
            seen_motion = False
            # Pregrasp snapshot is captured by FPGA CMD03. Then set the closing target.
            for i in range(8):
                regs.write(REG["target"] + i * 4, 950)
            regs.write(REG["torque"], 0x88888888)
            regs.write(REG["speed"], 80)
            regs.write(REG["ctrl"], 1)
            regs.write(REG["cmd"], 0x000003)
            for i in range(8):
                regs.write(REG["target"] + i * 4, 1450)
            regs.write(REG["cmd"], 0x000101)
            print("自动演示启动：预张 → FPGA 闭合 → FPGA 保持 → 自动释放。观察 MuJoCo 窗口即可。")
            deadline = time.monotonic()
            rx = bytearray()
            while True:
                status = regs.read(REG["status"])
                state = status & 0x7
                if state != state_prev:
                    print(f"FPGA FSM: {STATE.get(state, 'UNKNOWN')}  status=0x{status:08x}")
                    state_prev = state
                if state != 0:
                    seen_motion = True
                if state == 3:
                    if hold_started is None:
                        hold_started = time.monotonic()
                    elif time.monotonic() - hold_started >= args.hold_seconds:
                        regs.write(REG["cmd"], 0x000002)
                        hold_started = float("inf")

                # Actual FSM mux target, not the planned TARGET registers.
                target = [regs.read(REG["target"] + i * 4) & 0xFFF for i in range(8)]
                seq += 2
                msg = {"seq": seq, "state": state, "target_raw": target}
                sock_file.write((json.dumps(msg, separators=(",", ":")) + "\n").encode())
                reply = recv_line(sock, rx)
                if reply.get("seq") != seq or len(reply.get("position_raw", [])) != 8:
                    raise ValueError("invalid or stale MuJoCo feedback")
                for i, pos in enumerate(reply["position_raw"]):
                    load = int(reply.get("load_raw", [0] * 8)[i])
                    if not 0 <= int(pos) <= 1800 or not 0 <= load <= 1023:
                        raise ValueError("feedback outside MJC1 virtual range")
                    regs.write(REG["feedback"] + i * 4, int(pos) | (load << 12))
                regs.write(REG["commit"], seq | 1)
                if state == 0 and seen_motion:
                    print("闭环演示已释放回到 IDLE；窗口保持打开，可继续观察。")
                    break
                deadline += args.period
                time.sleep(max(0.0, deadline - time.monotonic()))
    except (OSError, ValueError, ConnectionError, RuntimeError) as exc:
        print(f"闭环停止：{exc}")
        try:
            regs.write(REG["ctrl"], 0x3)
        except Exception:
            pass
        return 2
    finally:
        regs.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
