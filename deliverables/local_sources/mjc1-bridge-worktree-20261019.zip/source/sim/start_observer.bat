@echo off
setlocal
cd /d "%~dp0\.."
if exist "sim\.venv_mjc\Scripts\python.exe" (
  "sim\.venv_mjc\Scripts\python.exe" "sim\mujoco_observer.py" --bind 0.0.0.0 --port 8765
) else (
  python "sim\mujoco_observer.py" --bind 0.0.0.0 --port 8765
)
pause
