"""No-board smoke check for the actual upstream hand MuJoCo model + TCP framing."""
from __future__ import annotations

import json
import socket
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sim.mujoco_observer import Observer, serve  # noqa: E402


def main() -> int:
    observer = Observer(trace=None, load_gain=32.0)
    server_sock, client = socket.socketpair()
    worker = threading.Thread(target=serve, args=(server_sock, observer), daemon=True)
    worker.start()
    seq = 2
    opened = [900] * 8
    closed = [1450] * 8
    positions = []
    try:
        for state, target in [(0, opened)] * 20 + [(2, closed)] * 60 + [(4, opened)] * 40:
            seq += 2
            client.sendall((json.dumps({"seq": seq, "state": state, "target_raw": target}) + "\n").encode())
            data = bytearray()
            while b"\n" not in data:
                data.extend(client.recv(4096))
            line, _, rest = data.partition(b"\n")
            # Each response is one frame; the loop intentionally sends one at a time.
            reply = json.loads(line)
            if reply.get("seq") != seq or len(reply.get("position_raw", [])) != 8:
                raise AssertionError(f"bad feedback response: {reply}")
            positions.append(reply["position_raw"])
        travel = max(abs(positions[-1][0] - p[0]) for p in positions)
        if travel < 50:
            raise AssertionError(f"MuJoCo joint did not follow the command; travel={travel} raw")
        if not all(0 <= p <= 1800 for frame in positions for p in frame):
            raise AssertionError("MuJoCo feedback exceeded MJC1 virtual range")
        print(f"MUJOCO_OBSERVER_PASS: model actuators={observer.model.nu}, first joint travel={travel} raw, frames={len(positions)}")
    finally:
        client.close()
        worker.join(timeout=2)
        observer.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
